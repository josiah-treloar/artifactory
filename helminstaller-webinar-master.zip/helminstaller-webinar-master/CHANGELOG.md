# JFrog Helm Installer Webinar

All changes to this chart will be documented in this file.

## [1.0.0] - Sept 02, 2020
* Artifactory-HA, Xray, Distribution, Mission Control, and Pipelines simplified helm installer scripts.
